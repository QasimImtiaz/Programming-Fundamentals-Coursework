/* 
 * File:   LinkedList.cpp
 * Author: Qasim Imtiaz
 *
 * Last modified 30/03/2017
 * Implements the LinkedList class.
 */

#include <string>
#include <cassert>
#include <iostream>
#include <sstream>
#include "linked_list.h"
using namespace std;

//creates an empty list
LinkedList::LinkedList()
{
	//head and tail is set to null by default
	this->head = nullptr; 
	this->tail = nullptr; 
}

//creates a list with an initial value to store
LinkedList::LinkedList(int value)
{
	//Allocate a new node in memory
	Node *currentNode = new Node; 
    //Set the next node to null
	currentNode->next = nullptr;
	//Set the node data to value
	currentNode->data = value; 
	//set head to the current node and set tail to head
	head = currentNode; 
	tail = head; 
}

//copy constructor (performs a deep copy)
LinkedList::LinkedList(const LinkedList& rhs)
{
	if (rhs.head == nullptr)
		return;

	Node *currentNode = rhs.head;
	//Allocate a new node in memory
	head = new Node;
	//Copy over the value
	head->data = currentNode->data;
	//Set the next value to null
	head->next = nullptr;
	//Point tail to head
	tail = head;

	//Move to next value in rhs list
	currentNode = currentNode->next;

	while (currentNode != nullptr)
	{
		//Allocate new memory for a new node
		tail->next = new Node;
		//point to this new node
		tail = tail->next;
		//copy over the data
		tail->data = currentNode->data;
		//By default set the nextNode to null
		tail->next = nullptr;
		//Move along rhs list
		currentNode = currentNode->next;
	}
}

//destroys (cleans up) the list
LinkedList::~LinkedList()
{
	//Point tail to head
	tail = head;
	while (tail != nullptr)
	{
		//set tail to next node
		tail = tail->next;
		//remove head
		delete head;
		//set head to tail
		head = tail;
	}
}

//adds a value to the head of the list
void LinkedList::push(int value)
{
	//Allocate new memory for a new node
    Node *currentNode = new Node;
	//Node is set to value
	currentNode->data = value; 
	//The next node is set to null
	currentNode->next = nullptr; 

	if (head == nullptr) {
		//head is set to current node
		head = currentNode; 
		//tail is set to head
		tail = head; 
	}
	
	else
	{
		//The next node is set to head node
		currentNode->next = head; 
		//tail is set to head
		tail = head;
		//head is set to the currentNode
		head = currentNode;
	}
}

//gets the last element from the list, without removing it
//requires: list not empty
int LinkedList::peekTail()
{
	if (tail == nullptr) return -1;
	return tail->data;
}

//prints the list in order from head to tail
string LinkedList::toString() const
{
	string str;
	string result;

	//currentNode is made and it is set to head by default
	Node *currentNode = head; 

	while(currentNode != nullptr)
	{
		str = to_string(currentNode->data);
		//currentNode is set to the next node
		currentNode = currentNode->next; 

		if(result == "")
			result = str;
		else 
			result = result + " " + str; 
	}
	return result;
}

//removes and returns the value at the head of the list
//requires: list not empty
int LinkedList::pop()
{
	int value;
	Node *currentNode; 

	//Check that list is not empty
	if (head != nullptr)
	{
		//The node is set to the node after the head node
		currentNode = head->next;
		//value is set to head data
		value = head->data; 
		//Remove head
		delete head;
		//head is set to the currentNode
		head = currentNode;
		//return head value
		return value; 
	}

	else
		return 0;
}

//adds a value to the end of the list
void LinkedList::append(int value)
{
	//Allocate new memory for a new node
	Node *currentNode = new Node; 
	//The node data is set to value
	currentNode->data = value;
	//The next node is set to null by default
	currentNode->next = nullptr;

	if (tail == nullptr)
		//head is set to the current node
		head = currentNode; 

	else
		//the next tail node is set to the current node
		tail->next = currentNode; 

	//tail is set to the current node
	tail = currentNode; 
}

//appends the deep copies of the nodes of rhs on to the end of this list
void LinkedList::appendList(const LinkedList& rhs)
{
	//Allocate new memory for a new node
	Node *tempNode;
	//The node is set to rhs head
	tempNode = rhs.head; 
	//current node is set to tail by default
	Node *currentNode = tail; 
	while (tempNode != nullptr)
	{
		//Allocate new memory for a new node
		Node *temp2 = new Node;
		//Copy over the value
		temp2->data = tempNode->data;
		//set the next node to the temp2 node
		currentNode->next = temp2;
		//set current node to the next node
		currentNode = currentNode->next;
		//set the temporary node to the next node
		tempNode = tempNode->next;
	}
}

//inserts a value immediately after the first occurrence of afterValue,
//if afterValue is not in the list then inserts at the tail
void LinkedList::insertAfter(int value, int afterValue)
{
	//Allocate new memory for a new node
	Node *tempNode = new Node;
	//set node to a value
	tempNode->data = value;
	//set the previous node to null by default
	Node *prevNode = nullptr;
	//set the current node to head
	Node *currentNode = head;
	//initialise flag value to 0
	int flag = 0;

	while (currentNode != nullptr) {
		Node *temp;
		//check if afterValue is the in list
		if (currentNode->data == afterValue) 
		{
			//set temp to next node
			temp = currentNode->next;
			//set next node to a temporary node
			currentNode->next = tempNode;
			//set the next node to temp
			tempNode->next = temp;
			//set flag to 1
			flag = 1;
			//loop terminated
			break;
		}
		//previous node is set to the current node
		prevNode = currentNode;
		//current node is set to the next node
		currentNode = currentNode->next;
	}

	if (flag == 0)
		//next node of previous node is set to the tempNode 
		prevNode->next = tempNode;
}


//removes all occurrences of value from the list
void LinkedList::removeAllOccurences(int value)
{
	Node newNode;
	//the next node is set to head
	newNode.next = head; 
	//new memory is allocated for a new node
	Node *currentNode = &newNode; 
	while (currentNode->next != nullptr)
	{
		if (currentNode->next->data == value)
		{
			//New node is made and is set to the next node
			Node *tempNode = currentNode->next;
			//The next node of current node is set to next node of temporary node
			currentNode->next = tempNode->next;
			//values of tempNode is removed
			delete tempNode;
		}
		else
		{
			//current node is set to the next node
			currentNode = currentNode->next;
		}
	}
	//head is set to the next node of the new node
	head = newNode.next; 
}


//reverses the list
void LinkedList::reverse()
{
	if(head == nullptr)
	{
		return;
	}

	//All nodes is set to null by default
	Node *currentNode = nullptr;
	Node *prevNode = nullptr;
	Node *nextNode = nullptr; 

	//The current node is set to head
	currentNode = head; 
	
	while(currentNode != nullptr)
	{
		//next node of current node
		nextNode = currentNode->next;
		//The next node is set to the previous node
		currentNode->next = prevNode;
		//previous node is set to the current node
		prevNode = currentNode;
		//current node is set to the next node
		currentNode = nextNode;
	}
	
	//head pointing to prevNode
	head = prevNode;
}

//checks if two lists are equal in state (contain the same values in the same order)
bool LinkedList::operator ==(const LinkedList& other) const
{
	//Test if the two lists are equal
	return (other.head && this->head) && (other.tail && this->tail); 
}

//checks if two lists are not equal in state
bool LinkedList::operator !=(const LinkedList& other) const
{
	//flag is initialised to 1
	int flag = 1;
	//temp2 is set to head node and temp2 is set to the other head node
	Node *temp1 = head;
	Node *temp2 = other.head;
	while (temp1 != nullptr && temp2 != nullptr)
	{
		if (temp1->data != temp2->data) 
			//flag is set to 0
			flag = 0;

		//temp1 and temp2 is both set to the next node 
		temp1 = temp1->next; temp2 = temp2->next;
	}
	if (temp1 == nullptr || temp2 == nullptr && !(temp1 == nullptr&&temp2 == nullptr))
		//flag is set to 0
		flag = 0;

	if (flag == 1)
		return false;

	return true; 
}

//pushes a new value onto the head of the list
LinkedList& LinkedList::operator +(int value)
{
	//Allocate new memory for a new node
	Node *temp = new Node;
	//The node is set to value
	temp->data = value;
	//The next node is set to head
	temp->next = head;
	//The head is set to the node
	head = temp;

	return *this; 
}

//copy assignment operator (performs a deep copy)
LinkedList& LinkedList::operator =(const LinkedList& rhs)
{
	//new memory is allocated for a new node
	Node *dummy = new Node;
	Node *dummyHead = dummy;
	//temporay node is inialised to the rhs head
	Node *temp = rhs.head;
	while (temp != NULL) {
		//new memory is allocated for a new node
		Node *temp2 = new Node;
		//copy over values 
		temp2->data = temp->data;
		//the next node of dummy is set to temp2 node
		dummy->next = temp2;
		//dummy is set to next node
		dummy = dummy->next;
		//temp is set to the next node
		temp = temp->next;
	}
	//head is set to the next node of dummyHead
	head = dummyHead->next;
	//tail node is set to dummy node
	tail = dummy;
	//the next node of dummy is set to null 
	dummy->next = nullptr;

	return *this; 
}

//pushes values from an input stream onto the front of the list
std::istream& operator>>(std::istream &in, LinkedList &value)
{
	//head node of value is set to null by default
	value.head = nullptr;
	//flag and test is set to 0 by default
	int flag = 0;
	int test = 0;
	while (!in.eof())
	{
		int inInteger;
		//input to the integer
		in >> inInteger;
		if (test == 1) break;
		if (inInteger == 2) test = 1;
		//Allocate new memory for new node
		Node *temp = new Node;
		//temp is set to the input integer
		temp->data = inInteger;
		//the next node is set to value head
		temp->next = value.head;
		//value head is set to teh temp node
		value.head = temp;
		if (flag == 0) {
			//the value tail is set to temp
			value.tail = temp;
			//flag is set to 1
			flag = 1;
		}
	}
	return in;
}

//writes the values, in order, to an output stream
std::ostream& operator<<(std::ostream &out, const LinkedList &value)
{
	//output values to output stream
	out << value.toString();
    return out;
}
